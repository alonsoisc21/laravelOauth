<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //fillable= rellenable
    protected $fillable=['title','body'];
}
