<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('/favicon.ico')); ?>" />
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/vendor/normalizev8.0.0.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/vendor/jquery-ui.1.12.1.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap4.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('images/open-iconic-master/font/css/open-iconic-bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/layout-master.css')); ?>">
    <?php echo $__env->yieldContent('estilos'); ?>
  </head>
  <body>
    <?php $__env->startSection('cabecera'); ?>
      <header class="cabecera"style="max-width:auto">
        <div class="row">
          
          <div class="col-5 col-sm-5 col-md-5 col-lg-5 col-xl-5">
            <a href="<?php echo e(url('/dashboard')); ?>" title="Inicio">
              <img src="<?php echo e(asset('images/claro.png')); ?>" class="img-fluid" alt="claro-360" style="min-width:110px;height:40px;">
            </a>
          </div>

          <div class="col-5 col-sm-5 col-md-6 col-lg-6 col-xl-6">
              
          </div>
          
        </div>
      </header>
    <?php echo $__env->yieldSection(); ?>
   
       
        <div class="content">
                <div class="title m-b-md incidentes" >
                    <a href="<?php echo e(route('login')); ?>">Login</a>

                    <a href="<?php echo e(route('register')); ?>">Registrar</a>
                </div>

                <div class="title m-b-md incidentes" >
                    Incidentes

                    <?php echo $__env->make('fragmento', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

        </div>



    <div class="container-fluid contenido">
      <?php echo $__env->yieldContent('contenido'); ?>
    </div>

    <!-- /.modal de Mensajes -->
  <div class="modal fade" id="modalMensajes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title">Mensaje:</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div><!-- /.modal-header -->
        <div class="modal-body">
          <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <span aria-hidden="true"></span>
            </div>
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
              <h4 id="mensaje"></h4>
            </div>
          </div>
        </div><!-- /.modal-body -->
        <div class="modal-footer">
          <button type="button" class="btn btn-primary" id="bttn-modal-a">Aceptar</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        </div><!-- /.modal-footer -->
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->

    
    
    <script type="text/javascript" src="<?php echo e(asset('js/vendor/jquery-3.2.1.slim.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/vendor/popper-1.12.9.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap4.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/vendor/modernizr-3.5.0.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/vendor/jquery-ui.1.12.1.js')); ?>"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <script type="text/javascript">
      var rutaApp = '<?php echo url('/'); ?>' + '/';
      $.datepicker.regional['es'] = {
        closeText: 'Cerrar',
        prevText: '< Ant',
        nextText: 'Sig >',
        currentText: 'Hoy',
        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
        monthNamesShort: ['Ene','Feb','Mar','Abr', 'May','Jun','Jul','Ago','Sep', 'Oct','Nov','Dic'],
        dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
        dayNamesShort: ['Dom','Lun','Mar','Mié','Juv','Vie','Sáb'],
        dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sá'],
        weekHeader: 'Sm',
        dateFormat: 'dd-mm-yy',
        firstDay: 1,
        isRTL: false,
        showMonthAfterYear: false,
        yearSuffix: ''
       };
       $.datepicker.setDefaults($.datepicker.regional['es']);
    </script>

    <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>
