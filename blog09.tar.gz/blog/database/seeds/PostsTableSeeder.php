<?php

use Illuminate\Database\Seeder;
use App\Post;//Especificar el modelo

class PostsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //Especificar inserte 40 registros.
        //el cual hace referencia a carpeta
        //factory
        factory(Post::class,40)->create();
    }
}
