<!DOCTYPE html>
<html>
<head>
	<title></title>
	<title>TestApi</title>
	<style type="text/css">
		input{
			margin-bottom: 5px;
			display: block;
		}
	</style>

	<script type="text/javascript">
		/*onload=function(){
			alert("Funcionando !!!!.");
		}*/
	</script>
</head>
<body>
hollla
    <form method="POST">
		<input type="email" id="email" placeholder="Email" />
		<input type="password" id="password" placeholder="Contraseña" />
		<input type="submit" id="login" value="Ingresar" />
	</form>


	<script type="text/javascript">
		
	onload=function(){

	const clientId = 1;
	const clientSecret = 'fkpiCNM5OR4mPbZjQT9sSvbldKHo480E4EAAHKxW';
	const grantType = 'password';

	let login = document.getElementById('login');

	login.addEventListener('click',function(e){

		e.preventDefault();
		    fetch('http://localhost/oauth/token', {
		    method: 'POST',
		    headers: {
		      "Content-type": "application/json"
		    },
		    body:JSON.stringify({
		    	client_id:clientId,
				client_secret:clientSecret,
				grant_type:grantType,
				username:document.getElementById('email').value,
				password:document.getElementById('password').value
		    })
			})
			.then(function (response) {
				return response.json();
			})
			.then(
				function(data){
					console.log(data.access_token);
					//Guardando en el localstorage
					localStorage.setItem('token',data.access_token);
				}
			)
			.catch(function (error) {
			    console.log('Request failed', error);
			 }); 

	});

   
	}
 	</script>
</body>
</html>
